settings = {
    "mongoUrl": "mongodb+srv://admin:admin@cluster0.0rips.mongodb.net/test"+'?ssl=true&ssl_cert_reqs=CERT_NONE',
    "database": "musicTutor",
    "songCol": "songs"
}

ACCESS_KEY = 'AKIA4BFL45UA4BYQ7XLP'
SECRET_KEY = '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'